# HW2 Xin Guan

## q6:
All my plots and codes are in `q6.ipynb`. open or run it will give out all the results.

## q7:

There are 3 files doing q7: `q7ab.ipynb`, `q7c.ipynb`.

In `q7ab.ipynb`, the answer to part a and part b.

In `q7c.ipynb`, the answer to part c. I just modified little code, so it is similar to part a and b's code with lambda added.